Bom dia professor, espero que esteja bem e que sua mãe esteja melhor.

Estou mandando o trabalho da Maquina de Turing. Como eu tô com o tempo muito corrido por causa do fim de semestre e com o trabalho, eu não fiz com entrada de arquivo para economizar tempo. No lugar de um arquivo, dentro do código tem um array chamado "entry" bem parecido com o especificado no trabalho. Também tem um comentário explicando a montagem do array e das regras (mudei só que no lugar de receber "Y/Y R", ele recebe ['Y', 'Y', 'R']).

Eu testei com a linguagem L(m) = {a^nb^n | n > 0}. Porém, como é um modelo universal, é esperado que ele execute corretamente qualquer linguagem de acordo com a 'entry' colocada e a fita.


Cordialmente,
Uriel A de oliveira Lasheras